Hermmy Wang, 704978214, hermmyw@hotmail.com
Zhenghao Li, 704971934, lizhenghao99@g.ucla.edu

Sources
=======
- OpenCV
	A computer vision module in Python. 
	Used for preprocessing and extracting features from images.

- Scikit-Learn
	A machine learning module in Python.
	Used for implementing K-means and agglomerative clustering algorithms.
	Used for implementing KNN and SVM classification.

- Numpy
	Arrays in Python

- Time
	Record runtime. 